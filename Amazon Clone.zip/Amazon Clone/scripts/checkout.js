import {renderOrderCart} from './checkout/orderSummery.js';
import {renderPaymentSummery} from './checkout/paymentSummery.js';
renderOrderCart();
renderPaymentSummery();